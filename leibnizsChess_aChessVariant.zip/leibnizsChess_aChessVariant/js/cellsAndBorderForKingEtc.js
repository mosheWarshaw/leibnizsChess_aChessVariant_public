"use strict";
import {checkColor} from "./checkColor.js";
import {emptyAndNotSpace} from "./emptyAndNotSpace.js";
export{cellsAndBorderForKingEtc, cellsAndBorderForPawns};
/*The cells that pass all the tests and are cells that the piece can be moved to are given a cyan border
so the user knows where they can move, and those cell numbers are stored in the secondCellOptionsForKingEtc array so
they can be used in the second turn when deciding if the user should be allowed to put the piece in the
cell they want to. The program checks if the user is trying to put the piece in a cell that is one of the
cells in the array.*/

/* I check if the piece can move to the cell, and if it can, I give it a cyan border.
I check a cell that I know it can move to based on the blue number (I check the red in the last if
statement in the process of checking the cell). If it isn't empty, I check if it is a piece of the
same color, in which case it wouldn't be allowed to move there. I check if the cell is empty or
containing a piece of a different color, and I check the red. If it passes those checks, the
cell gets a cyan border.*/

/*When I write kingEtc I'm referring to the king, pawn, shield , prince, and general.
This excludes the bishop and rook. All of these, except the bishop and rook, have similar functions
and can be grouped into one category.
Below is the only time kingEtc excludes pawns. cellAndBorderForKingEtc doesn't include pawns; the pawns have
their own function*/
function cellsAndBorderForKingEtc(secondCellOptionsPar, pickedUpPiecesBlue, pickedUpPiecesColor, movesArray, pieceIsShield){
    let addNum;
    let secondCell;
    let redOfFirstCell;
    let redOfSecondCell;
    let redMinusRed;
    let secondCellsPiece;
    let secondCellsPieceColor;
    let colorPassesTest;
    let emptyAndNotSpacePassesTest;

    for(let i = 0; i < movesArray.length; i++){
        addNum = movesArray[i];
        /*secondCell is the cell that the piece is going to be evaluated if it can be placed there. in the rookOrBishop
        files this variable for it is called cellAndC .*/
        secondCell = pickedUpPiecesBlue + addNum;
        secondCellsPiece = $("#" + secondCell + " img").attr("src");
        secondCellsPieceColor = $("#" + secondCell + " img").attr("class");
        colorPassesTest = checkColor(pickedUpPiecesColor, secondCellsPieceColor);
        emptyAndNotSpacePassesTest = emptyAndNotSpace(secondCell);
        /*if there is an opponents piece in the cell, or the cell is empty and it's not a space, then the cell
        will be further evaluated if the piece can be placed there.*/
        if(colorPassesTest || emptyAndNotSpacePassesTest){
            /*let me explain this with the king. the king cna move from one cell to the other if the difference in
            blue is 1 (it can move in other ways but this is the one i'll deal with). however, the king cannot go from
            11 to 12, even though the difference in blue is 1. the program knows when to allow th eking ot move
            when the difference is 1 by ensuring that the difference in red is less than 90.*/
            redOfSecondCell = parseInt($("#" + secondCell).attr("title"));
            redOfFirstCell = parseInt($("#" + pickedUpPiecesBlue).attr("title"));
            redMinusRed = Math.abs(redOfSecondCell - redOfFirstCell);
            /*the cell is one that can be moved to and will get a cyan border if the redMinusRed is
            less than 90. the second part of the conditional enforces that if the picked up piece
            is a shield then the secondCell must be empty (because a shield can't kill), or the piece isn't
            a shield.*/
            if((redMinusRed < 90) && ((pieceIsShield && emptyAndNotSpacePassesTest) || !pieceIsShield)){
                /*I have css for this class that gives a cyan border. I remove the class when going through
                the array of cells in the second turn.*/
                $("#" + secondCell).addClass("cyanBorder");
                /* Adds the id of the cell to the list that the program will use later to check if the cell
                the user clicks on to put the piece down is one of these cells that the program is checking
                now if it can be moved to*/
                secondCellOptionsPar[secondCellOptionsPar.length] = secondCell;
            }
        }
    }
    return secondCellOptionsPar;
}

function cellsAndBorderForPawns(secondCellOptionsPar, pickedUpPiecesBlue, ten, eleven, one, equal10, otherPiecesColor){
    let blueFirstCellAnd10;
    let blueFirstCellAnd11;
    let blueFirstCellAnd1;
    let redOfSecondCell;
    let redOfFirstCell;
    let secondCellsPieceColor;
    blueFirstCellAnd10 = pickedUpPiecesBlue + ten;
    /* I don't need to check the color for when it moves ten blue, because this would be it moving forward,
    and a pawn can't kill forward. If a piece is in front of it, eve if it's the enemies, it can't move forward. */
    redOfSecondCell = parseInt($("#" + blueFirstCellAnd10).attr("title"));
    redOfFirstCell = parseInt($("#" + pickedUpPiecesBlue).attr("title"));
    if(emptyAndNotSpace(blueFirstCellAnd10) && (redOfSecondCell - redOfFirstCell == equal10) ){
        $("#" + blueFirstCellAnd10).addClass("cyanBorder");
        secondCellOptionsPar[secondCellOptionsPar.length] = blueFirstCellAnd10;
    }

    // Moving 11 and moving 1 is diagonal movement.
    blueFirstCellAnd11 = pickedUpPiecesBlue + eleven;
    if($("#" + blueFirstCellAnd11).attr("src") != ""){
        secondCellsPieceColor = $("#" + blueFirstCellAnd11 + " img").attr("class");
        /* I can't use the colorCheck() because that checks if the second cell is empty or is the opponent's piece.
        The pawn can't move diagonally if the cell is empty, and the rest of the pieces can, so it's easier to write
        code for the pawn rather than change the function and have t write code for all the other pieces.*/
        if(secondCellsPieceColor == otherPiecesColor){
            $("#" + blueFirstCellAnd11).addClass("cyanBorder");
            secondCellOptionsPar[secondCellOptionsPar.length] = blueFirstCellAnd11;
        }
    }
    blueFirstCellAnd1 = pickedUpPiecesBlue + one;
    if($("#" + blueFirstCellAnd1).attr("src") != ""){
        secondCellsPieceColor = $("#" + blueFirstCellAnd1 + " img").attr("class");
        if(secondCellsPieceColor == otherPiecesColor){
            $("#" + blueFirstCellAnd1).addClass("cyanBorder");
            secondCellOptionsPar[secondCellOptionsPar.length] = blueFirstCellAnd1;
        }
    }
    return secondCellOptionsPar;
}