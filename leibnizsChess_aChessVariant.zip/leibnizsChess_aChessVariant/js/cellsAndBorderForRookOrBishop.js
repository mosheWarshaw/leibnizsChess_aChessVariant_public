"use strict";
import {emptyAndNotSpace} from "./emptyAndNotSpace.js";
import {checkColor} from "./checkColor.js";
export{cellsAndBorderForRookOrBishop};
function cellsAndBorderForRookOrBishop(secondCellOptionsPar, pickedUpPiecesBlue, pickedUpPiece, pickedUpPiecesColor){
    let tenOrTwelve;
    let oneOrEleven;
    let plusOrMinus;
    let cellAndC;
    let redOfCellAndC;
    let redOfPreviousCell;
    let redMinusRed;
    let keepChecking;
    let plus = 1;
    let minus = -1;
    let cellAndCsPiece;
    let colorPassesTest;
    let emptyAndNotSpacePassesTest;
    let secondCellsPieceColor;

    /*this outer for loop will run the inner one 4 times. the inner for loop checks all the cells in a row,
    and this outer one has each of the 4 directions checked.
    the 4 directions are left to right, right to left, up to down, and down to up.
    the reason there's a left to right and a right to left (it's the same reason for having an up to down
    and a down to up) is because the way i check left to right is from the cell where the piece was to the leftmost
     cell, and the way i check right to left is from the cell where the piece was to the rightmost cell.
     to understand why i do this think about the way a rook can move: it can move as far outward in a direction until
     the end of the row is reached unless a piece is in its way; so just because a piece can or cannot move in
     a direction, or how far it can move in one direction, does not effect at all how far it can move in the other
     direction.*/
    for(let i = 0; i < 4; i++){
        keepChecking = true;
        /*when the rook moves from left to right (it's simplest to understand when you look at teh top row, which
         is 1 through 11 in blue),assuming it started in 1 blue and you want to move it one to the right you
         can add 11 to the first cell's red and you'd get the second cell's red. Each cell in the row is 11 away
         from the previous one. To reach a cell that is 2 spaces away, add 22 (this is 2 * 11) to the first cell to
         reach it. You can reach any cell in the row by adding 11 or 11 times a number between 1 and 10.
         To go from right to left you do the same thing except you subtract 11 instead of adding 11.
         Going from top to bottom and bottom to top is the same idea, but you use 1, not
         eleven, so 2 of the iterations 11 is going to be used and the other 2 times 1 will be used (this is
         the oneOrEleven variable). Every other iteration i'm either adding or subtracting. adding 1 allows me
         to go left ot right, and subtracting it allows me to go right to left. adding 11 allows me to go up
         to down, and subtracting 11 allows me to go down to up. this is what the plusOrMinus is.
         the bishop is the same but it uses 10 or 12 instead of 1 or eleven.
         for both the rook and bishop, the difference in red can't be more than 90.*/
        if(i < 2){
            tenOrTwelve = 10;
            oneOrEleven = 1;
        }
        else{
            tenOrTwelve = 12;
            oneOrEleven = 11;
        }
        /*if i is even then I'm either checking left to right or up to down, so I'm adding 11, so plusOrMinus is
        assigned plus. if it's not even then i'm going right to left or down to up, in which case
        i'm subtracting 11, so plusOrMinus is assigned minus.*/
        if(i % 2 == 0){
            plusOrMinus = plus;
        }
        else{
            plusOrMinus = minus;
        }

        for (let c = 1; (c < 11) && keepChecking; c++){
            if(pickedUpPiece == "images/whiteRookCropped.png" ||
                    pickedUpPiece == "images/blackRookCropped.png"){
                /*Multiplying it by negative 1 will turn the number into a negative, and it will be like
                subtracting the number from blueFirstCell.*/
                cellAndC = pickedUpPiecesBlue + (plusOrMinus * (c * oneOrEleven));
                redOfPreviousCell = parseInt($("#" + (pickedUpPiecesBlue + (plusOrMinus * ((c - 1) * oneOrEleven)))).attr("title"));
            }
            /*if it's not a rook then it's the bishop because these are the only two pieces that would have
            this function called.*/
            else{
                cellAndC = pickedUpPiecesBlue + (plusOrMinus * (c * tenOrTwelve));
                redOfPreviousCell = parseInt($("#" + (pickedUpPiecesBlue + (plusOrMinus * ((c - 1) * tenOrTwelve)))).attr("title"));
            }
            redOfCellAndC = parseInt($("#" + cellAndC).attr("title"));
            redMinusRed = Math.abs(redOfCellAndC - redOfPreviousCell);
            if(redMinusRed > 90){
                keepChecking = false;
            }

            /* You need the loop to iterate the full 10 times to get 10 * 12
            in case the bishop is in cell 1, because it should be able to move to cell 121.
            However if you start in cell 50, for example, (or any number more than 1),
            the loop is checking cells that don't exist on the board. It's checking (10 * 12)
            plus 50. there is no cell 170. Therefore, if the cell that is being checked is over 121,
            the code isn't checking cells on the board anymore, and the code is told to stop checking.
            This is also the case for the rook, because it checks cells in the same way.

            For the same reason you stop checking if you're looking at numbers that are off the board because
            you were adding and got a sum greater than 121, you also stop checking if you were subtracting and
            got a difference that was less than 1.*/
            if(cellAndC > 121 || cellAndC < 1){
                keepChecking = false;
            }

            if(keepChecking){
                cellAndCsPiece = $("#" + cellAndC + " img").attr("src");
                secondCellsPieceColor = $("#" + cellAndC + " img").attr("class");
                colorPassesTest = checkColor(pickedUpPiecesColor, secondCellsPieceColor);
                emptyAndNotSpacePassesTest = emptyAndNotSpace(cellAndC);
                /*If the cell is of a piece of the opponents color, or if the cell is empty and not a space cell,
                then the program adds the cell to the list and put a border around it.*/
                if(colorPassesTest || emptyAndNotSpacePassesTest){
                    $("#" + cellAndC).addClass("cyanBorder");
                    secondCellOptionsPar[secondCellOptionsPar.length] = cellAndC;
                }
                if((!colorPassesTest && !emptyAndNotSpacePassesTest) || colorPassesTest){
                    /*If it's a cell that the piece can't be put down then the body of the above if statement
                    didn't run and the cell didn't get a cyan border and wasn't added to the
                    secondCellOptionsForRookOrBishopPar array, and now we can set keepChecking to
                    false because there if you reached a cell you can't put the piece in then the rest of the cells in
                    that direction can't have the piece put in it.
                    keepChecking is also set to false if colorPassesTest is true. it being true means the cell has an
                    opponents piece in it. the body of th eif statement would run because the rook and bishop can be
                    put in a cell that has an opponent's piece in it, but they can't be put in any cells behind that
                    cell in that direction (e.g. if the rook is in 4 and an opponents piece is in 5, the rook can be
                    put in 5, but not 6, 7, 8, 9, 10 , or 11).. so the cell with the opponents piece gets a cyan border
                    and is added to the array, but i stop checking the direction.*/
                    keepChecking = false;
                }
            }
        }
    }
    return secondCellOptionsPar;
}