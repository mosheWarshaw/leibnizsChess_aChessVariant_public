export{checkColor};
/*This is used to makes sure that the user isn't trying to put his piece in a spot where there is a piece that is its
own color.*/
function checkColor(piecesColor, secondCellsPieceColor){
    if((piecesColor == "white"  && secondCellsPieceColor == "black") || (piecesColor == "black" &&
        secondCellsPieceColor == "white")){
        return true;
    }
    else if((piecesColor == "white" && secondCellsPieceColor == "white") || (piecesColor == "black"
        && secondCellsPieceColor == "black")){
        return false;
    }
}