"use strict";
export{emptyAndNotSpace};
/*These cells can't have pieces put on them. I keep them so there can still be the shape of a board,
but so it's not confusing which cells can't be used they're made opaque.
these cells are just space, they can't be used, but it's still there, so i call them spaceCells.*/
let spaceCells = [1, 2, 3, 12, 13, 23, 99, 109, 110, 119, 120, 121];
//blueOfCell is the blue number of the cell. it's the id.
function emptyAndNotSpace(blueOfCell){
    let empty;
    /*checking if the src attr is an empty string checks if it has an image of a piece being displayed,
    which is the same as finding out if the cell is empty.*/
    if($("#" + blueOfCell + " img").attr("src") == ""){
        empty = true;
    }
    else{
        empty = false;
    }

    let notSpace;
    if($("#" + blueOfCell).hasClass("spaceCells")){
        notSpace = false;
    }
    else{
        notSpace = true;
    }

    return notSpace && empty;
}