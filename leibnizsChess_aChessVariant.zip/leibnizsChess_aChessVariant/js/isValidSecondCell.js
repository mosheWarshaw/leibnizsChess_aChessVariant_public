"use strict";
export{isValidSecondCell};
function isValidSecondCell(secondCellsBlue, secondCellOptions){
    /* Checks if the user is trying to move the cell into one of the cells that the program figured out was
    allowed to when doing the cyan border thing in the first turn. */
    for(let i = 0; i < secondCellOptions.length; i++){
        if(secondCellsBlue == secondCellOptions[i]){
            return true;
        }
    }
    return false;
}