"use strict";
import {cellsAndBorderForKingEtc, cellsAndBorderForPawns} from "./cellsAndBorderForKingEtc.js"
import {cellsAndBorderForRookOrBishop} from "./cellsAndBorderForRookOrBishop.js"
import {putPieceDown} from "./putPieceDown.js";
import {isValidSecondCell} from "./isValidSecondCell.js";
/*A user's move is separated into 2 turns of clicking on cells. The first turn is the user clicking on a cell that
holds a piece they ant to move. The piece is picked up, and cells that the user can put the piece down in get a cyan
border. The user's second turn is clicking on the cell that the user wants to place the piece in.
Note: if the cell is an invalid place the user can put the piece in, the cyan borders will disappear, but the
user still has to put the piece down, and it must be in a valid cell.*/
let clickTurn = "pickUp";
//white goes first.
let colorsTurn = "white";
let valid = false;
let piece;
let piecesColor;
/*blueFirstCell refers to the blue cell number of the cell that the piece is being picked up from. blueSecondCell
is the blue cell number of the cell that the user wants to put the piece down in.*/
let blueFirstCell;
//this is the red number of the cell the piece was picked up from.
let redFirstCell;
let blueSecondCell;
/*the first element is the lessThan, and the rest are the values when added to the blueCellFirst you get the blue
cell number of the cell the piece can move to. let me give you an example of what "can move to" means for a king.
the king can move one space in any direction unless a piece of its own color is in the cell. the purpose of the
lessThan is that the king can move ot the right by adding one to the blueFirstCell. however, if the king
is at the rightmost cell in a row, adding one would take it to the start fo another row, which the king cannot do.
the lessThan is the distance in red that the piece has to be moving within. It cannot move from one cell to another
of the difference in red of the two cells is more than 90. this ensures that the ling will not be allowed to move
across rows just because the difference in blue is 1. all pieces have the same idea of a lessThan, though they
are different numbers because the piece's movements are different and they would be illegally moving to different
cell in a different way. this is the reason why cells are given red numbers as well as blue numbers.

The cells that the piece can move to are given a cyan border, and these cell numbers are stored in the
secondCellsOptions array so when the user clicks on a cell it wants to place the piece it picked up, the
program checks if the blue number of that cell is one of the elements of this array. if it is, the program
lets the user move there. if it isn't, the program doesn't.*/
let kingArray = [1, -1, 10, -10, 11, -11, 12, -12];
let princeArray = [2, -2, 20, -20, 22, -22, 24, -24];
let secondCellOptions;

$("td").click(function(){
    if(clickTurn == "pickUp"){
        blueFirstCell = parseInt($(this).attr("id"));
        redFirstCell = parseInt($(this).attr("title"));
        redFirstCell = parseInt($(this).attr("title"));
        piece = $("#" + blueFirstCell + " img").attr("src");
        piecesColor = $("#" + blueFirstCell + " img").attr("class");
        /*each color takes turns picking up one of their pieces and moving it. if a piece is moved that isn't
        the color of the one whose turn it is then the body of the if statement that causes the piece to be picked
        up and have the cyan borders set and store the valid cells the piece cna be moved to in an array. nothing
        will be done and the user will have to click on a piece that is of the right color.*/
        if(piecesColor == colorsTurn){
            /*removes teh class color from the cell that the piece is icked up from because it's not going to
            have a piece in it.*/
            $("#" + blueFirstCell + " img").removeClass(piecesColor);
            //puts an empty string in place of the lin to the pieces image. it's making the cell empty.
            $("#" + blueFirstCell + " img").attr("src", "");

            if(piece == "images/whiteKingCropped.png" || piece == "images/blackKingCropped.png"){
                /*as you can see, secondCellOptions is redefined before each function so that it doesn't
                hold any of the cell numbers from teh previous turn.*/
                secondCellOptions = [];
                secondCellOptions = cellsAndBorderForKingEtc(secondCellOptions, blueFirstCell, piecesColor,
                    kingArray, false);
            }
            else if(piece == "images/whitePrinceCropped.png" || piece == "images/blackPrinceCropped.png"){
                secondCellOptions = [];
                secondCellOptions = cellsAndBorderForKingEtc(secondCellOptions, blueFirstCell, piecesColor,
                    princeArray, false);
            }
            else if(piece == "images/whiteGeneralCropped.png" || piece == "images/blackGeneralCropped.png"){
                secondCellOptions = [];
                //The general can move like a king and prince.
                secondCellOptions = cellsAndBorderForKingEtc(secondCellOptions, blueFirstCell, piecesColor,
                    kingArray, false);
                /*there are probably going to be elements in secondCellOptions from the function call above, so when
                it's passed in below it's going to be returned with new elements added onto after those.*/
                secondCellOptions = cellsAndBorderForKingEtc(secondCellOptions, blueFirstCell, piecesColor,
                    princeArray, false);
            }
            // The black and white pawns have different rules of movement, so they're separate.
            else if(piece == "images/whitePawnCropped.png") {
                secondCellOptions = [];
                secondCellOptions = cellsAndBorderForPawns(secondCellOptions, blueFirstCell, -10, -11, 1, 10, "black");
            }
            else if(piece == "images/blackPawnCropped.png"){
                secondCellOptions = [];
                secondCellOptions = cellsAndBorderForPawns(secondCellOptions, blueFirstCell, 10, 11, -1, -10, "white");
            }
            else if(piece == "images/whiteShieldCropped.png" || piece == "images/blackShieldCropped.png"){
                    secondCellOptions = [];
                    //The shield moves the same as the king so the same array can be passed in.
                    secondCellOptions = cellsAndBorderForKingEtc(secondCellOptions, blueFirstCell, piecesColor,
                        kingArray, true);
            }
            else if(piece == "images/whiteRookCropped.png" || piece == "images/blackRookCropped.png"){
                secondCellOptions = [];
                secondCellOptions = cellsAndBorderForRookOrBishop(secondCellOptions, blueFirstCell, piece, piecesColor);
            }
            else if(piece == "images/whiteBishopCropped.png" || piece == "images/blackBishopCropped.png"){
                secondCellOptions = [];
                /*the bishop can move like a king and the way a bishop moves in traditional chess. this function
                finds the cells that the bishop can move to regarding its king-like movements.
                it will give a cyan border to those cells, and it will store those numbers in its own
                secondCellOptions. I take that array and add it to this secondCellOptions array (it doesn't
                actually hold that array, rather it now references it, but it can be expanded when the cells for
                the cells for the bishop-like movements are added).*/
                secondCellOptions = cellsAndBorderForKingEtc(secondCellOptions, blueFirstCell, piecesColor,
                    kingArray, false);
                secondCellOptions = cellsAndBorderForRookOrBishop(secondCellOptions, blueFirstCell, piece, piecesColor);
            }

            clickTurn = "putDown";
        }
    }
    else{
        blueSecondCell = parseInt($(this).attr("id"));

        /*if the user is clicking on teh same cell that it picked the piece up from then the user
        wants to put it back so it can move a different piece. i allow the user to do this so it can
        pick up a piece to see the cyan borders and where it could go without having to then
        move it.
        if the user isn't putting it in the same cell then i evaluate if the cell is one of the cells
        from the array that have the cyan border that i know the user and move to,
        and if it is then the piece is put down, or the user will have to put it in a cell it can be moved
        to. it can put it back in the same it was picked up from, but this would not count as the user's
        move. the user would have to move a different piece.*/
        if(blueFirstCell == blueSecondCell){
            putPieceDown(blueSecondCell, piece, piecesColor);
            $("td").removeClass("cyanBorder");
            //i set clickTurn to pickUp so the user cna now pick up a different piece.
            clickTurn = "pickUp";
        }
        else{
            valid = isValidSecondCell(blueSecondCell, secondCellOptions);

            /* Since the following code is not run unless the user clicks on a valid place it can put it's piece down,
            it remains the second turn (players switch off making moves, and each move is divided into turns of before
            and after a piece is picked up. After picking up a piece is the second. The first turn ends when the user
            picks up a piece, and hte second turn ends when it puts it down), the user is still holding the piece it
            picked up, and there is no error. It just has to click on a valid cell to put it in (and it doesn't matter
            how many times the user clicks on invalid cells), and the next player moves, and the game continues as if
            nothing happened. */
            if(valid){
                putPieceDown(blueSecondCell, piece, piecesColor);
                $("td").removeClass("cyanBorder");
                clickTurn = "pickUp";
                //now that the turn is over its the other colors turn to go, and I change colorsTurn to reflect this.
                if(piecesColor == "white"){
                    colorsTurn = "black";
                }
                else{
                    colorsTurn = "white";
                }
                /*resetting valid to false so that the next turn the user can't click on any cell and be
                allowed to put it there just because valid is true from the previous turn.*/
                valid = false;
            }
        }
    }
})