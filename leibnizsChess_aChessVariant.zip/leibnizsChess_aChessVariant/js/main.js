"use strict";
import {pickUpKingEtc, pickUpPawn} from "./pickUpKingEtcOrPawn.js"
import {pickUpRookOrBishop} from "./pickUpRookOrBishop.js"
import {putPieceDown} from "./putPieceDown.js";
import {screenSecondCell} from "./screenSecondCell.js";
/*a user's move is separated into 2 turns of clicking on cells. the first turn is the user clicking on a cell that
holds a piece they want to move. the piece is picked up, and cells that the user can put the piece down in get a cyan
border. the user's second turn is clicking on the cell that the user wants to place the piece in.*/
let clickTurn = "pickUp";
//white goes first.
let colorsTurn = "white";
let valid = false;
let piece;
let piecesColor;
/*firstCellsBlue refers to the blue cell number of the cell that the piece is being picked up from. secondCellsBlue
is the blue cell number of the cell that the user wants to put the piece down in.*/
let firstCellsBlue;
//the red number of the cell the piece was picked up from.
let firstCellsRed;
let secondCellsBlue;
let kingArray = [1, -1, 10, -10, 11, -11, 12, -12];
let princeArray = [2, -2, 20, -20, 22, -22, 24, -24];
let whitePawnArray = [-10, -11, 1, 10];
let blackPawnArray = [10, 11, -1, -10];
let secondCellOptions;

$("td").click(function(){
    if(clickTurn == "pickUp"){
        firstCellsBlue = parseInt($(this).attr("id"));
        firstCellsRed = parseInt($(this).attr("title"));
        piece = $("#" + firstCellsBlue + " img").attr("src");
        piecesColor = $("#" + firstCellsBlue + " img").attr("class");
        if(piecesColor == colorsTurn){
            $("#" + firstCellsBlue + " img").removeClass(piecesColor);
            $("#" + firstCellsBlue + " img").attr("src", "");

            if(piece == "images/whiteKingCropped.png" || piece == "images/blackKingCropped.png"){
                /*secondCellOptions is redefined before each function so that it doesn't
                hold any of the cell numbers from the previous turn.*/
                secondCellOptions = [];
                secondCellOptions = pickUpKingEtc(secondCellOptions, firstCellsBlue, piecesColor, kingArray, false);
            }
            else if(piece == "images/whitePrinceCropped.png" || piece == "images/blackPrinceCropped.png"){
                secondCellOptions = [];
                secondCellOptions = pickUpKingEtc(secondCellOptions, firstCellsBlue, piecesColor,
                    princeArray, false);
            }
            else if(piece == "images/whiteGeneralCropped.png" || piece == "images/blackGeneralCropped.png"){
                secondCellOptions = [];
                //The general can move like a king and prince.
                secondCellOptions = pickUpKingEtc(secondCellOptions, firstCellsBlue, piecesColor, kingArray, false);
                /*there are probably going to be elements in secondCellOptions from the function call above, so when
                it's passed in below it's going to be returned with new elements added onto after those.*/
                secondCellOptions = pickUpKingEtc(secondCellOptions, firstCellsBlue, piecesColor, princeArray, false);
            }
            // The black and white pawns have different rules of movement, so they're separate.
            else if(piece == "images/whitePawnCropped.png") {
                secondCellOptions = [];
                secondCellOptions = pickUpPawn(secondCellOptions, firstCellsBlue, whitePawnArray, "black");
            }
            else if(piece == "images/blackPawnCropped.png"){
                secondCellOptions = [];
                secondCellOptions = pickUpPawn(secondCellOptions, firstCellsBlue, blackPawnArray, "white");
            }
            else if(piece == "images/whiteShieldCropped.png" || piece == "images/blackShieldCropped.png"){
                    secondCellOptions = [];
                    //The shield moves the same as the king so the same array can be passed in.
                    secondCellOptions = pickUpKingEtc(secondCellOptions, firstCellsBlue, piecesColor,
                        kingArray, true);
            }
            else if(piece == "images/whiteRookCropped.png" || piece == "images/blackRookCropped.png"){
                secondCellOptions = [];
                secondCellOptions = pickUpRookOrBishop(secondCellOptions, firstCellsBlue, piece, piecesColor);
            }
            else if(piece == "images/whiteBishopCropped.png" || piece == "images/blackBishopCropped.png"){
                secondCellOptions = [];
                //the bishop can move like a king and the way a bishop moves in traditional chess.
                secondCellOptions = pickUpKingEtc(secondCellOptions, firstCellsBlue, piecesColor,
                    kingArray, false);
                secondCellOptions = pickUpRookOrBishop(secondCellOptions, firstCellsBlue, piece, piecesColor);
            }

            clickTurn = "putDown";
        }
    }
    else{
        secondCellsBlue = parseInt($(this).attr("id"));

        /*the user to do put a piece down in the cell it was picked up from and not have this count
         as the user's move, because i want the user to be able to see the cyan borders and where it could go
         without having to then move it.*/
        if(firstCellsBlue == secondCellsBlue){
            putPieceDown(secondCellsBlue, piece, piecesColor);
            $("td").removeClass("cyanBorder");
            clickTurn = "pickUp";
        }
        else{
            valid = screenSecondCell(secondCellsBlue, secondCellOptions);

            /* Since the following code is not run unless the user clicks on a valid place it can put it's piece down,
            it remains the second turn, the user is still holding the piece it picked up, and there is no error. It
            just has to click on a valid cell to put it in (and it doesn't matter how many times the user clicks on
            invalid cells).*/
            if(valid){
                putPieceDown(secondCellsBlue, piece, piecesColor);
                $("td").removeClass("cyanBorder");
                clickTurn = "pickUp";
                if(piecesColor == "white"){
                    colorsTurn = "black";
                }
                else{
                    colorsTurn = "white";
                }
                valid = false;
            }
        }
    }
});