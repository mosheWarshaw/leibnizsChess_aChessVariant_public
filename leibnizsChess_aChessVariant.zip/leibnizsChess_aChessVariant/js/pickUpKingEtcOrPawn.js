"use strict";
import {checkColor} from "./checkColor.js";
import {emptyAndNotOpaque} from "./emptyAndNotOpaque.js";
export{pickUpKingEtc, pickUpPawn};
/*i check if the piece can move to the cell, and if it can, i give it a cyan border.
i check a cell that I know it can move to based on the difference in blue. i check if the cell is empty or
containing a piece of a different color, and i check the red. if it passes these checks, the
cell gets a cyan border.
the cells that the piece can be moved to are given a cyan border so the user knows where they can move, and those
cell numbers are stored in the secondCellOptionsForKingEtc array so they can be used in the second turn when deciding
if the user should be allowed to put the piece in the cell they clicked on. the program checks if the user is trying
to put the piece in a cell that is one of the cells in the array.*/

/*when I write kingEtc I'm referring to the king, shield , prince, or general.
this excludes the bishop and rook. all of these, except the bishop and rook, have similar functions
and can be grouped into one category.*/
function pickUpKingEtc(secondCellOptionsPar, firstCellsBlue, pickedUpPiecesColor, movesArray, pieceIsShield){
    let addNum;
    let secondCell;
    let redOfFirstCell;
    let redOfSecondCell;
    let redMinusRed;
    let secondCellsPiece;
    let secondCellsPieceColor;
    let colorPassesTest;
    let emptyAndNotSpacePassesTest;

    for(let i = 0; i < movesArray.length; i++){
        addNum = movesArray[i];
        //secondCell is the cell that the piece is going to be evaluated if it can be placed there.
        secondCell = firstCellsBlue + addNum;
        secondCellsPiece = $("#" + secondCell + " img").attr("src");
        secondCellsPieceColor = $("#" + secondCell + " img").attr("class");
        colorPassesTest = checkColor(pickedUpPiecesColor, secondCellsPieceColor);
        emptyAndNotSpacePassesTest = emptyAndNotOpaque(secondCell);
        if(colorPassesTest || emptyAndNotSpacePassesTest){
            redOfSecondCell = parseInt($("#" + secondCell).attr("title"));
            redOfFirstCell = parseInt($("#" + firstCellsBlue).attr("title"));
            redMinusRed = Math.abs(redOfSecondCell - redOfFirstCell);
            if((redMinusRed < 90) && ((pieceIsShield && emptyAndNotSpacePassesTest) || !pieceIsShield)){
                /*I have css for this class that gives a cyan border. I remove the class when going through
                the array of cells in the second turn.*/
                $("#" + secondCell).addClass("cyanBorder");
                secondCellOptionsPar[secondCellOptionsPar.length] = secondCell;
            }
        }
    }
    return secondCellOptionsPar;
}

function pickUpPawn(secondCellOptionsPar, firstCellsBlue, pawnsArray, otherPiecesColor){
    let secondCellsPieceColor;
    let firstCellsBlueAnd10 = firstCellsBlue + pawnsArray[0];
    let firstCellsBlueAnd11 = firstCellsBlue + pawnsArray[1];
    let firstCellsBlueAnd1  = firstCellsBlue + pawnsArray[2];
    let equals10 = pawnsArray[3];

    let redOfFirstCell = parseInt($("#" + firstCellsBlue).attr("title"));
    let redOfSecondCell= parseInt($("#" + firstCellsBlueAnd10).attr("title"));
    /*I don't need to check the color for when it moves ten blue, because moving ten is moving forward,
    and a pawn can't kill forward. If a piece is in front of it, even if it's the enemy's, it can't move forward.*/
    if(emptyAndNotOpaque(firstCellsBlueAnd10) && (redOfSecondCell - redOfFirstCell == equals10)){
        $("#" + firstCellsBlueAnd10).addClass("cyanBorder");
        secondCellOptionsPar[secondCellOptionsPar.length] = firstCellsBlueAnd10;
    }

    //moving 11 and moving 1 is diagonal movement.
    if($("#" + firstCellsBlueAnd11).attr("src") != ""){
        secondCellsPieceColor = $("#" + firstCellsBlueAnd11 + " img").attr("class");
        /*i can't use the colorCheck() because that checks if the second cell is empty or is the opponent's piece,
        and the pawn can't move diagonally if the cell is empty.*/
        if(secondCellsPieceColor == otherPiecesColor){
            $("#" + firstCellsBlueAnd11).addClass("cyanBorder");
            secondCellOptionsPar[secondCellOptionsPar.length] = firstCellsBlueAnd11;
        }
    }
    if($("#" + firstCellsBlueAnd1).attr("src") != ""){
        secondCellsPieceColor = $("#" + firstCellsBlueAnd1 + " img").attr("class");
        if(secondCellsPieceColor == otherPiecesColor){
            $("#" + firstCellsBlueAnd1).addClass("cyanBorder");
            secondCellOptionsPar[secondCellOptionsPar.length] = firstCellsBlueAnd1;
        }
    }
    return secondCellOptionsPar;
}