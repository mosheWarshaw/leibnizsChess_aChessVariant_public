"use strict";
export{putPieceDown};
function putPieceDown(secondCellsBlue, thePiece, colorOfPiece){
    $("#" + secondCellsBlue + " img").attr("class", colorOfPiece);

    let pieceIsKing = thePiece == "images/blackKingCropped.png" ||
        thePiece == "images/whiteKingCropped.png";
    let pieceIsShield = thePiece == "images/blackShieldCropped.png" ||
        thePiece == "images/whiteShieldCropped.png";
    //kings and shields are the only pieces that won't change when placed into a purple cell.
    if(pieceIsKing || pieceIsShield){
        $("#" + secondCellsBlue + " img").attr("src", thePiece);
    }
    else{
        if(secondCellsBlue == 10 || secondCellsBlue == 112){
            $("#" + secondCellsBlue + " img").attr("src", "images/" + colorOfPiece + "GeneralCropped.png");
        }
        else if(secondCellsBlue == 20 || secondCellsBlue == 61 || secondCellsBlue == 102){
            $("#" + secondCellsBlue + " img").attr("src", "images/" + colorOfPiece + "PrinceCropped.png");
        }
        else if(secondCellsBlue == 7 || secondCellsBlue == 41 || secondCellsBlue == 44 || secondCellsBlue == 78 ||
        secondCellsBlue == 81 || secondCellsBlue == 115){
            $("#" + secondCellsBlue + " img").attr("src", "images/" + colorOfPiece + "RookCropped.png");
        }
        else if(secondCellsBlue == 8 || secondCellsBlue == 37 || secondCellsBlue == 55 ||
        secondCellsBlue == 67 || secondCellsBlue == 85 || secondCellsBlue == 114){
            $("#" + secondCellsBlue + " img").attr("src", "images/" + colorOfPiece + "BishopCropped.png");
        }
        else{
            $("#" + secondCellsBlue + " img").attr("src", thePiece);
        }
    }
}