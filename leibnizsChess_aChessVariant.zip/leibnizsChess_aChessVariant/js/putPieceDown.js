"use strict";
export{putPieceDown};
/*This puts the piece in the cell that was clicked on if isValidSecondCell returned true that the user
clicked on a cell that was in teh secondCellOptions array.
if the user clicked on a purple cell and is allowed to move there then teh piece will be changed,
so this will take care of changing git if it has to be changed when put down as well.*/
function putPieceDown(secondCellBlue, thePiece, colorOfPiece){
    $("#" + secondCellBlue + " img").attr("class", colorOfPiece);

    let pieceIsKing = thePiece == "images/blackKingCropped.png" ||
        thePiece == "images/whiteKingCropped.png";
    let pieceIsShield = thePiece == "images/blackShieldCropped.png" ||
        thePiece == "images/whiteShieldCropped.png";
    //kings and shields are the only pieces that won't change when turned placed into a purple cell.
    if(pieceIsKing || pieceIsShield){
        $("#" + secondCellBlue + " img").attr("src", thePiece);
    }
    else{
        if(secondCellBlue == 10 || secondCellBlue == 112){
            $("#" + secondCellBlue + " img").attr("src", "images/" + colorOfPiece + "GeneralCropped.png");
        }
        else if(secondCellBlue == 20 || secondCellBlue == 61 || secondCellBlue == 102){
            $("#" + secondCellBlue + " img").attr("src", "images/" + colorOfPiece + "PrinceCropped.png");
        }
        else if(secondCellBlue == 7 || secondCellBlue == 41 || secondCellBlue == 44 || secondCellBlue == 78 ||
        secondCellBlue == 81 || secondCellBlue == 115){
            $("#" + secondCellBlue + " img").attr("src", "images/" + colorOfPiece + "RookCropped.png");
        }
        else if(secondCellBlue == 8 || secondCellBlue == 37 || secondCellBlue == 55 ||
        secondCellBlue == 67 || secondCellBlue == 85 || secondCellBlue == 114){
            $("#" + secondCellBlue + " img").attr("src", "images/" + colorOfPiece + "BishopCropped.png");
        }
        else{
            $("#" + secondCellBlue + " img").attr("src", thePiece);
        }
    }
}