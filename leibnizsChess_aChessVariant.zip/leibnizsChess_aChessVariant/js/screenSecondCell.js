"use strict";
export{screenSecondCell};
function screenSecondCell(secondCellsBlue, secondCellOptions){
    for(let i = 0; i < secondCellOptions.length; i++){
        if(secondCellsBlue == secondCellOptions[i]){
            return true;
        }
    }
    return false;
}