"use strict";
let idValueBlue = 1;
/*i explain in the code when its uses come up why i give a red number and a blue number.
those explanations will be easier to understand with a visual aid, so in the images folder I included
the original board with the red and bue numbers that i drew when creating the variant.*/
let titleValueRed = 1;
for(var i = 0; i < 11; i++){
    document.getElementsByTagName("table")[0].insertAdjacentHTML("beforeend", "<tr></tr>");
    for(let ii = 0; ii < 11; ii++){
        document.getElementsByTagName("tr")[i].insertAdjacentHTML("beforeend", "<td id='" + idValueBlue +
        "' title='" + titleValueRed + "'><img src=''></td>");

        if(idValueBlue < 21){
            if(idValueBlue == 7 || idValueBlue == 8 || idValueBlue == 10 || idValueBlue == 20){
                $("#" + idValueBlue).css("backgroundColor", "hsl(276, 61%, 19%)");
            }
        }
        else if(idValueBlue < 45){
            if(idValueBlue == 37 || idValueBlue == 41 || idValueBlue == 44){
                $("#" + idValueBlue).css("backgroundColor", "hsl(276, 61%, 19%)");
            }
        }
        else if(idValueBlue < 86){
            if(idValueBlue == 55 || idValueBlue == 61 || idValueBlue == 67 || idValueBlue == 78 || idValueBlue == 81 ||
                    idValueBlue == 85){
                $("#" + idValueBlue).css("backgroundColor", "hsl(276, 61%, 19%)");
            }
        }
        else if(idValueBlue < 116){
            if(idValueBlue == 102 || idValueBlue == 112 || idValueBlue == 114 || idValueBlue == 115){
                $("#" + idValueBlue).css("backgroundColor", "hsl(276, 61%, 19%)");
            }
        }

        idValueBlue += 1;
        titleValueRed += 11;
    }
    titleValueRed = 2 + i;
}
/*These cells can't have pieces put on them. I keep them so there can still be the shape of a board,
but so it's not confusing which cells can't be used they're made opaque.
these cells are just space, they can't be used, but it's still there, so i call them spaceCells.*/
let  spaceCells = [1, 2, 3, 12, 13, 23, 99, 109, 110, 119, 120, 121];
for(let i = 0; i < spaceCells.length; i++){
    $("#" + spaceCells[i]).css("opacity", ".4");
}

$("#setUpButton").click(function(){
    $("#11 img").attr("src", "images/blackKingCropped.png");
    /*all black pieces get the class "black", and the white pieces get class "white".
    these classes don't do anything; they're used so the pieces color can be checked by looking
    at its class.*/
    $("#11 img").addClass("black");
    $("#10 img").attr("src", "images/blackGeneralCropped.png");
    $("#10 img").addClass("black");
    $("#8 img").attr("src", "images/blackBishopCropped.png");
    $("#8 img").addClass("black");
    $("#7 img").attr("src", "images/blackRookCropped.png");
    $("#7 img").addClass("black");
    $("#20 img").attr("src", "images/blackPrinceCropped.png");
    $("#20 img").addClass("black");
    $("#18 img").attr("src", "images/blackPawnCropped.png");
    $("#18 img").addClass("black");
    $("#17 img").attr("src", "images/blackPawnCropped.png");
    $("#17 img").addClass("black");
    $("#31 img").attr("src", "images/blackShieldCropped.png");
    $("#31 img").addClass("black");
    $("#30 img").attr("src", "images/blackPawnCropped.png");
    $("#30 img").addClass("black");
    $("#29 img").attr("src", "images/blackPawnCropped.png");
    $("#29 img").addClass("black");
    $("#44 img").attr("src", "images/blackRookCropped.png");
    $("#44 img").addClass("black");
    $("#43 img").attr("src", "images/blackPawnCropped.png");
    $("#43 img").addClass("black");
    $("#42 img").attr("src", "images/blackPawnCropped.png");
    $("#42 img").addClass("black");
    $("#55 img").attr("src", "images/blackBishopCropped.png");
    $("#55 img").addClass("black");
    $("#54 img").attr("src", "images/blackPawnCropped.png");
    $("#54 img").addClass("black");
    $("#65 img").attr("src", "images/blackPawnCropped.png");
    $("#65 img").addClass("black");

    $("#111 img").attr("src", "images/whiteKingCropped.png");
    $("#111 img").addClass("white");
    $("#112 img").attr("src", "images/whiteGeneralCropped.png");
    $("#112 img").addClass("white");
    $("#114 img").attr("src", "images/whiteBishopCropped.png");
    $("#114 img").addClass("white");
    $("#115 img").attr("src", "images/whiteRookCropped.png");
    $("#115 img").addClass("white");
    $("#102 img").attr("src", "images/whitePrinceCropped.png");
    $("#102 img").addClass("white");
    $("#104 img").attr("src", "images/whitePawnCropped.png");
    $("#104 img").addClass("white");
    $("#105 img").attr("src", "images/whitePawnCropped.png");
    $("#105 img").addClass("white");
    $("#91 img").attr("src", "images/whiteShieldCropped.png");
    $("#91 img").addClass("white");
    $("#92 img").attr("src", "images/whitePawnCropped.png");
    $("#92 img").addClass("white");
    $("#93 img").attr("src", "images/whitePawnCropped.png");
    $("#93 img").addClass("white");
    $("#78 img").attr("src", "images/whiteRookCropped.png");
    $("#78 img").addClass("white");
    $("#79 img").attr("src", "images/whitePawnCropped.png");
    $("#79 img").addClass("white");
    $("#80 img").attr("src", "images/whitePawnCropped.png");
    $("#80 img").addClass("white");
    $("#67 img").attr("src", "images/whiteBishopCropped.png");
    $("#67 img").addClass("white");
    $("#68 img").attr("src", "images/whitePawnCropped.png");
    $("#68 img").addClass("white");
    $("#57 img").attr("src", "images/whitePawnCropped.png");
    $("#57 img").addClass("white");
})