"use strict";
let src7;
let src8;
let src10;
let src20;
let src37;
let src41;
let src44;
let src48;
let src55;
let src61;
let src67;
let src74;
let src78;
let src81;
let src85;
let src102;
let src112;
let src114;
let src115;

/*the user hovers on this button to remind themself of what their piece will be changed to if placed in one of the
purple cells.*/
$("#showPurpleImgs").mouseenter(function(){
    //saves what was in the purple cells before the hover.
    src7 = $("#7 img").attr("src");
    src8 = $("#8 img").attr("src");
    src10 = $("#10 img").attr("src");
    src20 = $("#20 img").attr("src");
    src37 = $("#37 img").attr("src");
    src41 = $("#41 img").attr("src");
    src44 = $("#44 img").attr("src");
    src55 = $("#55 img").attr("src");
    src61 = $("#61 img").attr("src");
    src67 = $("#67 img").attr("src");
    src78 = $("#78 img").attr("src");
    src81 = $("#81 img").attr("src");
    src85 = $("#85 img").attr("src");
    src102 = $("#102 img").attr("src");
    src112 = $("#112 img").attr("src");
    src114 = $("#114 img").attr("src");
    src115 = $("#115 img").attr("src");

    // Displays what the cell converts the piece to that enters it.
    $("#7 img").attr("src", "images/purpleRookCropped.png");
    $("#8 img").attr("src", "images/purpleBishopCropped.png");
    $("#10 img").attr("src", "images/purpleGeneralCropped.png");
    $("#20 img").attr("src", "images/purplePrinceCropped.png");
    $("#37 img").attr("src", "images/purpleBishopCropped.png");
    $("#41 img").attr("src", "images/purpleRookCropped.png");
    $("#44 img").attr("src", "images/purpleRookCropped.png");
    $("#55 img").attr("src", "images/purpleBishopCropped.png");
    $("#61 img").attr("src", "images/purplePrinceCropped.png");
    $("#67 img").attr("src", "images/purpleBishopCropped.png");
    $("#78 img").attr("src", "images/purpleRookCropped.png");
    $("#81 img").attr("src", "images/purpleRookCropped.png");
    $("#85 img").attr("src", "images/purpleBishopCropped.png");
    $("#102 img").attr("src", "images/purplePrinceCropped.png");
    $("#112 img").attr("src", "images/purpleGeneralCropped.png");
    $("#114 img").attr("src", "images/purpleBishopCropped.png");
    $("#115 img").attr("src", "images/purpleRookCropped.png");
}).mouseleave(function(){
    //restores what was in the purple cells before the hover.
    $("#7 img").attr("src", src7);
    $("#8 img").attr("src", src8);
    $("#10 img").attr("src", src10);
    $("#20 img").attr("src", src20);
    $("#37 img").attr("src", src37);
    $("#41 img").attr("src", src41);
    $("#44 img").attr("src", src44);
    $("#48 img").attr("src", src48);
    $("#55 img").attr("src", src55);
    $("#61 img").attr("src", src61);
    $("#67 img").attr("src", src67);
    $("#74 img").attr("src", src74);
    $("#78 img").attr("src", src78);
    $("#81 img").attr("src", src81);
    $("#85 img").attr("src", src85);
    $("#102 img").attr("src", src102);
    $("#112 img").attr("src", src112);
    $("#114 img").attr("src", src114);
    $("#115 img").attr("src", src115);
});